# PrepWise AI

AI-powered Career Advisor & Interview Coach SaaS.

## Features
- User Registration & Login
- AI Career Advice
- AI Interview Feedback
- Dockerized Deployment
- PostgreSQL Database

## Run Locally

1. Copy .env.example to .env and add your OpenAI key
2. docker-compose up --build
3. Visit http://localhost:8000/docs
